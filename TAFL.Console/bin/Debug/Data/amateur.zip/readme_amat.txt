     Each record is in the following format:

      FIELD                        STARTING COLUMN   LENGTH
        ~~~~~                        ~~~~~~~~~~~~~~~   ~~~~~~
      Callsign                               1            6
      Given Names                            8           35
      Surname                               44           35
      Street Address                        80           70
      City                                 151           35
      Province                             187            2
      Postal/ZIP Code                      190           10
      BASIC Qualification (A)              201            1
      5WPM Qualification (B)               203            1
      12WPM Qualification (C)              205            1
      ADVANCED Qualification (D)           207            1
      Basic with Honours (E)               209            1
      Club Name (field 1)                  211           70
      Club Name (field 2)                  282           70
      Club Address                         353           70
      Club City                            424           35
      Club Province                        460            2
      Club Postal/ZIP Code                 463            7
